//
//  Common.h
//  TapTapPicture
//
//  Created by Dmitriy Semin on 02.11.12.
//  Copyright (c) 2012 Dmitriy Semin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Common : NSObject

+ (NSString *)pathToDocumentsDirectory;

@end
