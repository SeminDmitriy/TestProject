//
//  TapElementModel.m
//  TapTapPicture
//
//  Created by Dmitriy Semin on 27.10.12.
//  Copyright (c) 2012 Dmitriy Semin. All rights reserved.
//

#import "TapElementModel.h"

@implementation TapElementModel

@synthesize horizontalRow;
@synthesize verticalRow;
@synthesize imageElement;
@synthesize sizeElement;
@synthesize indexElement;
@synthesize hiddenElement;
@synthesize pathToHiddenElement;

@end
